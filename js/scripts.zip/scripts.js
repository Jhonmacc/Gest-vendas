//Todos os scritps





//Script puxa o mês ao clicar nos botões meses
$('.mes').on('click', function(){
  let mes = $(this).val();
 $('#recebeMes').val(mes);
  $('#formMes').submit();
}
)
//----------------------------------------------------------------------//

//Seleciona o produto e vem o preço no input valor
$('.produto-type').on('change', function() {
  $('.price-input')
    .val(
      $(this).find(':selected').data('price')
    );
});

//Seleciona o tipo da venda e vem o valor do benefício atribuido na value
$('.tipovenda-type').on('change', function() {
  $('.price-input')
    .val(
      $(this).find(':selected').data('price')
    );
});

// Ao marca o checkbox MF e vem o valor atribuido na value
let checkbox = $('.selecionar');
$(checkbox).on('change', function() {

  if (checkbox.is(':checked')) {

    $('.valor').val('GRATUITO - MPF')


  }

})

// Ao marca o checkbox Política de Garantia e vem o valor atribuido na value
let checkbox2 = $('.seleciona');
$(checkbox2).on('change', function() {

  if (checkbox2.is(':checked')) {

    $('.valor').val('GRATUITO - Política de Garantia')

  }
})


// Ao marca a checkbox Desconto Serasa desabtiva o readonly pro editar valor 
$('#flexSwitchCheckDefault').click(function() {
  $('.txtBloqueado').prop('readonly', false);
});
